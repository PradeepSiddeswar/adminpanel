import React from "react";

const ActiveUsers  = () => {
    return(
        <>
           <div style={{textAlign:'center', fontFamily:'Arial, sans-serof'}}>
        <h1 style={{color:'#333'}}>Number of Active Users</h1>
        <p style={{fontSize:'24px', color:'#27AE60', fontWeight:'bold'}}>500</p>
        <p style={{fontSize:'16px', color:"#888"}}>Currently active on the platform.</p>
    </div>
        </>
    )
}
 export default ActiveUsers;