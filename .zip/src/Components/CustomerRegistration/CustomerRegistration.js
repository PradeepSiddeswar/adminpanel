import React from "react";


const CustomerRegistration = () => {
    return(
        <>
        <h1>number of users</h1>
        </>
    )
}


export default CustomerRegistration;