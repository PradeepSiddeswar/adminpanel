import React from "react";
import LoginForm from "../Form/LoginForm";
import Navbar1 from "../Navbar/Navbar1";


const Home = () => {
    return(
        <>
    <Navbar1 />
    <LoginForm />
   
        </>
    )
}

export default Home;